#ifndef AP_ASSISTFIREWALL_CFG_H
#define AP_ASSISTFIREWALL_CFG_H

        extern void Rte_Call_AssistFirewall_Per1_CP0_CheckpointReached(void);
        extern void Rte_Call_AssistFirewall_Per1_CP1_CheckpointReached(void);


#endif 
