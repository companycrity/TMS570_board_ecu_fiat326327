#ifndef AP_RETURNFIREWALL_CFG_H
#define AP_RETURNFIREWALL_CFG_H

        extern void Rte_Call_ReturnFirewall_Per1_CP0_CheckpointReached(void);
        extern void Rte_Call_ReturnFirewall_Per1_CP1_CheckpointReached(void);


#endif 
