#ifndef AP_TRQCANC_CFG_H
#define AP_TRQCANC_CFG_H

        extern void Rte_Call_TrqCanc_Per1_CP0_CheckpointReached(void);
        extern void Rte_Call_TrqCanc_Per1_CP1_CheckpointReached(void);


#endif 
