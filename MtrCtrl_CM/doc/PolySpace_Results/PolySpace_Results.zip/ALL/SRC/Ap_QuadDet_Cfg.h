#ifndef AP_QUADDET_CFG_H
#define AP_QUADDET_CFG_H

        extern void Rte_Call_QuadDet_Per1_CP0_CheckpointReached(void);
        extern void Rte_Call_QuadDet_Per1_CP1_CheckpointReached(void);


#endif 
