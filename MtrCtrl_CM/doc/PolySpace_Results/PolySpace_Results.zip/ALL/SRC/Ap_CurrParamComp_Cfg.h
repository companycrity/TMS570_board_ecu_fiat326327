#ifndef AP_CURRPARAMCOMP_CFG_H
#define AP_CURRPARAMCOMP_CFG_H

        extern void Rte_Call_CurrParamComp_Per1_CP0_CheckpointReached(void);
        extern void Rte_Call_CurrParamComp_Per1_CP1_CheckpointReached(void);
        extern void Rte_Call_CurrParamComp_Per2_CP0_CheckpointReached(void);
        extern void Rte_Call_CurrParamComp_Per2_CP1_CheckpointReached(void);


#endif 
